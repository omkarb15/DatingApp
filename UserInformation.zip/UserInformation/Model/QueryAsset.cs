﻿namespace UserInformation.Model
{
    public class QueryAsset
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string SurName { get; set; }
        public DateTime DOB { get; set; }
        public string Gender { get; set; }
        public string EmialId { get; set; }
        public string UserName { get; set; }
        public string PassWord { get; set; }
        public string? ProfilImage { get; set; }

        public List<int> HobbyId { get; set; }

        public string HobbyName { get; set; }
    }
}