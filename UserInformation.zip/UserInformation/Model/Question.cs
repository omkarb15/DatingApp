﻿namespace UserInformation.Model
{
    public class Question
    {
        public int Id { get; set; }
        public string Gender { get; set; }
        public string QuestionText { get; set; }
    }
}
