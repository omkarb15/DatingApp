﻿using Microsoft.EntityFrameworkCore;

namespace UserInformation.Model
{
    public class UserContext : DbContext
    {
        public UserContext(DbContextOptions<UserContext> options) : base(options)
        {
        }
        public DbSet<Asset> Assets { get; set; }
        public DbSet<Hobby> Hobbies { get; set; }

        public DbSet<AssetHobby> AssetHobbies { get; set; }
        public DbSet<Question> Questions { get; set; }
   

      
    }
}
