﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using UserInformation.Model;

namespace UserInformation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly UserContext _context;

        
            public UsersController (UserContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<QueryAsset>>> GetAll()
        {
            var result = await _context.Assets
                .Select(asset => new QueryAsset
                {
                    Id = asset.Id,
                    FirstName = asset.FirstName,
                    SurName = asset.SurName,
                    DOB = asset.DOB,
                    Gender = asset.Gender,
                    EmialId = asset.EmialId,
                    UserName = asset.UserName,
                    PassWord = asset.PassWord,
                    ProfilImage = asset.ProfilImage,
                    HobbyName = string.Join(", ",
                        _context.AssetHobbies
                            .Where(ah => ah.AssetId == asset.Id)
                            .Join(_context.Hobbies,
                                  ah => ah.HobbyId,
                                  h => h.Id,
                                  (ah, h) => h.HobbyName)
                            .ToList()
                    )
                })
                .ToListAsync();

            return Ok(result);
        }






        [HttpPost]
        public async Task<ActionResult<QueryAsset>> AddUser([FromForm] Asset asset, [FromForm] IFormFile file, [FromForm] string hobbyIds)
        {
            try
            {
                // Handle Profile Image Upload
                if (file != null && file.Length > 0)
                {
                    var uploadFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                    if (!Directory.Exists(uploadFolder))
                    {
                        Directory.CreateDirectory(uploadFolder);
                    }
                    var fileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
                    var filePath = Path.Combine(uploadFolder, fileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }
                    var imageUrl = $"{Request.Scheme}://{Request.Host}/uploads/{fileName}";
                    asset.ProfilImage = imageUrl;
                }

                // Check if hobbyIds is empty
                if (string.IsNullOrEmpty(hobbyIds))
                {
                    return BadRequest("HobbyIds cannot be empty.");
                }

                List<int> hobbyIdList;
                if (hobbyIds.StartsWith("[") && hobbyIds.EndsWith("]"))
                {
                    hobbyIdList = JsonConvert.DeserializeObject<List<int>>(hobbyIds);
                }
                else
                {
                    hobbyIdList = hobbyIds.Split(',').Select(int.Parse).ToList();
                }

                // Save Asset (User) First
                await _context.Assets.AddAsync(asset);
                await _context.SaveChangesAsync();

                // Save Hobbies
                List<AssetHobby> assetHobbies = hobbyIdList
                    .Select(hobbyId => new AssetHobby { AssetId = asset.Id, HobbyId = hobbyId })
                    .ToList();

                await _context.AssetHobbies.AddRangeAsync(assetHobbies);
                await _context.SaveChangesAsync();

                // Get Hobby Details
                var hobbies = await _context.Hobbies
                    .Where(h => assetHobbies.Select(ah => ah.HobbyId).Contains(h.Id))
                    .ToListAsync();

                // Construct QueryAsset Response
                var queryAsset = new QueryAsset
                {
                    Id = asset.Id,
                    FirstName = asset.FirstName,
                    SurName = asset.SurName,
                    DOB = asset.DOB,
                    Gender = asset.Gender,
                    EmialId = asset.EmialId,
                    UserName = asset.UserName,
                    PassWord = asset.PassWord,
                    ProfilImage = asset.ProfilImage,
                    HobbyId = hobbies.Select(h => h.Id).ToList(),  // List of Hobby IDs
                    HobbyName = string.Join(", ", hobbies.Select(h => h.HobbyName))
                };

                return Ok(queryAsset);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }



        [HttpPut("{id}")]
        public async Task<ActionResult<Asset>> EditUser(int id, [FromForm] Asset asset, IFormFile? file) //? if user may or may not upload image , if not upload image then remain previous image there
        {
            var user = await _context.Assets.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }


            user.FirstName = asset.FirstName;
            user.SurName = asset.SurName;
            user.DOB = asset.DOB;
            user.Gender = asset.Gender;
            user.EmialId = asset.EmialId;
            user.UserName = asset.UserName;
            user.PassWord = asset.PassWord;

            
            if (file != null && file.Length > 0)
            {
               
                if (!string.IsNullOrEmpty(user.ProfilImage)) // to delete previous image from the folder
                {
                    var previousImagePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", Path.GetFileName(user.ProfilImage));// get the current directory of image and also GetFile- returns its name and extension
                    if (System.IO.File.Exists(previousImagePath))
                    {
                        System.IO.File.Delete(previousImagePath);
                    }
                }

                
                var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");// to create image for new user
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                var filename = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
                var filepath = Path.Combine(uploadsFolder, filename);

                using (var stream = new FileStream(filepath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                var imageUrl = $"{Request.Scheme}://{Request.Host}/uploads/{filename}";
                user.ProfilImage = imageUrl; 

            }

            _context.Assets.Update(user);
            await _context.SaveChangesAsync();

            return Ok(user);
        }


    

        [HttpDelete("{id}")]
        public async Task<ActionResult>DeleteUser(int id)
        {
            var user = await _context.Assets.FindAsync(id);
            if (user == null)
            {
                return NotFound("user is not found");
            }
            if (!string.IsNullOrEmpty(user.ProfilImage))
            {
                var filepath = (Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", Path.GetFileName(user.ProfilImage))); // wwwroot folder is default root directory that serving ststic files
                //if (System.IO.File.Exists(filepath))
                //{
                //    System.IO.File.Delete(filepath);
                //}
                var fileinfo = new FileInfo(filepath);
                if (fileinfo.Exists) {
                    fileinfo.Delete();
                }
                
            }
            _context.Assets.Remove(user);
            await _context.SaveChangesAsync();
            return NoContent();


        }



    }



}

